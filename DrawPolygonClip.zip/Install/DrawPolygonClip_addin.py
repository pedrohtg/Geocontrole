import arcpy
import pythonaddins
import os

class PolygonClip(object):
    """Implementation for DrawPolygonClip_addin.t1 (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Line"
        self.cursor = 3
    def onMouseDown(self, x, y, button, shift):
        pass
    def onMouseDownMap(self, x, y, button, shift):
        pass
    def onMouseUp(self, x, y, button, shift):
        pass
    def onMouseUpMap(self, x, y, button, shift):
        pass
    def onMouseMove(self, x, y, button, shift):
        pass
    def onMouseMoveMap(self, x, y, button, shift):
        pass
    def onDblClick(self):
        pass
    def onKeyDown(self, keycode, shift):
        pass
    def onKeyUp(self, keycode, shift):
        pass
    def deactivate(self):
        pass
    def onCircle(self, circle_geometry):
        pass
    def onLine(self, line_geometry):
    	shape = 'C:\Users\pedro\Documents\ArcGIS\polygons.shp'
    	root = 'C:/Users/pedro/Documents/ArcGIS/'
        arr = arcpy.Array()
        part = line_geometry.getPart(0)

        for pt in part:
        	print pt
        	arr.add(pt)
        arr.add(line_geometry.firstPoint)
        #arr.remove(-2)
        print arr[-1]
        #print arr
        print 'oe'

        polygon = arcpy.Polygon(arr)
        #arcpy.Polygon(arr)
        if arcpy.Exists(shape):
        	arcpy.Delete_management(shape)
        arcpy.CopyFeatures_management(polygon, 'polygons.shp')
        
        #--------------- Above is working -----------------------
        #--------------------------------------------------------

        mxd = arcpy.mapping.MapDocument('current')
        ext = polygon.extent
        rect = str(ext.XMin) + " " + str(ext.YMin) + " " + str(ext.XMax) + " " + str(ext.YMax)
        print rect

        for layer in arcpy.mapping.ListLayers(mxd):
        	if layer.isRasterLayer:
        		print layer.name

        		arcpy.Clip_management(in_raster=layer, rectangle=rect, out_raster=root+layer.name+"_clip",
        							  in_template_dataset="polygons.shp", nodata_value="255", clipping_geometry="ClippingGeometry",
        							  maintain_clipping_extent="NO_MAINTAIN_EXTENT")

        #rect = str(ex.XMin) + " " + str(ex.YMin) + " " + str(ex.XMax) + " " + str(ex.YMax)


	    #for layer in arcpy.mapping.ListLayers(mxd):
	    #	if layer.isRasterLayer:
	    		
	    		# arcpy.Clip_management(in_raster=layer, rectangle=rect, out_raster= root + layer.name + "_clip",
	    		# 					  in_template_dataset='polygons.shp', nodata_value="255", clipping_geometry="ClippingGeometry",
	    		# 					  maintain_clipping_extent="NO_MAINTAIN_EXTENT")



        # Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
		# The following inputs are layers or table views: "jpg1", "polygons"
		
		# arcpy.Clip_management(in_raster="jpg1", rectangle="641,653076171875 -601,369689941406 1853,21107617187 86,6757100585937",
		# 					  out_raster="C:/Users/pedro/Documents/ArcGIS/Default.gdb/jpg1_Clip1", in_template_dataset="polygons",
		# 					  nodata_value="255", clipping_geometry="ClippingGeometry", maintain_clipping_extent="NO_MAINTAIN_EXTENT")

        #return polygon

    def onRectangle(self, rectangle_geometry):
        pass